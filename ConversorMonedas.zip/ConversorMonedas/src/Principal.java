import java.util.Currency;
import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
       Scanner lectura = new Scanner(System.in);
        ConsultaCurrency consulta = new ConsultaCurrency();

        var opcionElegida = 0;
        while (opcionElegida!=7) {
            System.out.println("**********************************************************");
            System.out.println("Sea bienvenido al conversor de monedas");
            System.out.println("1) Dolar a Peso Argentino");
            System.out.println("2) Peso Argentino  a Dolar");
            System.out.println("3) Dolar a Real Brasileno");
            System.out.println("4) Real Brasileno a Dolar");
            System.out.println("5) Dolar a Peso Colombiano");
            System.out.println("6) Peso colombiano a Dolar");
            System.out.println("7) Salir");
            System.out.println("Elija opcion Valida");
            System.out.println("**********************************************************");
            opcionElegida = Integer.valueOf(lectura.nextLine());
            System.out.println("Ingrese el valor que desea convertir:");
            double monto = Double.valueOf(lectura.nextLine());
            if (opcionElegida == 1){
                Currency firstIntent = consulta.buscaCurrency("USD", "ARS",monto);
                System.out.println(firstIntent);
            }else if (opcionElegida == 2){
                Currency firstIntent = consulta.buscaCurrency("ARS", "USD",monto);
                System.out.println(firstIntent);
            }else if (opcionElegida == 3){
                Currency firstIntent = consulta.buscaCurrency("USD", "BRL",monto);
                System.out.println(firstIntent);
            }else if (opcionElegida == 4){
                Currency firstIntent = consulta.buscaCurrency("BRL", "USD",monto);
                System.out.println(firstIntent);
            }else if (opcionElegida == 5){
                Currency firstIntent = consulta.buscaCurrency("USD", "COP",monto);
                System.out.println(firstIntent);
            }else if (opcionElegida == 6){
                Currency firstIntent = consulta.buscaCurrency("COP", "USD",monto);
                System.out.println(firstIntent);
            }else {
                System.out.println("Intenta otra vez");
            }
        }

    }
}
